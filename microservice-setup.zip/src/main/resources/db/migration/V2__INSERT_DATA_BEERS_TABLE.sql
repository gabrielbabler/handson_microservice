INSERT INTO beers (name, price, description, alcohol_by_volume, type)
VALUES ("Skoll", 4.25, "A vida manda quadrado, você devolve redondo.", 2.1, "Lager");

INSERT INTO beers (name, price, description, alcohol_by_volume, type)
VALUES ("Brahma", 3.60, "Cerveja barata para churrasco", 2.8, "Lager");

INSERT INTO beers (name, price, description, alcohol_by_volume, type)
VALUES ("Itaipava", 2.79, "Leve para o churrasco e beba Skoll dos outros.", 1.9, "Lager");

INSERT INTO beers (name, price, description, alcohol_by_volume, type)
VALUES ("Heineken", 4.25, "Ui, ele bebe cerveja importada.", 2.4, "Lager");

INSERT INTO beers (name, price, description, alcohol_by_volume, type)
VALUES ("Kaiser", 1.99, "Cerveja raíz.", 3, "Lager");

INSERT INTO beers (name, price, description, alcohol_by_volume, type)
VALUES ("Budweiser", 5.30, "Cerveja que irá acabar primeiro no churrasco.", 2.9, "Lager");

INSERT INTO beers (name, price, description, alcohol_by_volume, type)
VALUES ("Stella Artois", 5.20, "Não leve para o churrasco, beba em casa.", 2.8, "Lager");

INSERT INTO beers (name, price, description, alcohol_by_volume, type)
VALUES ("Eisenbahn", 4.25, "Cerveja um pouco cara, mas vale a pena.", 2.1, "Pilsen");